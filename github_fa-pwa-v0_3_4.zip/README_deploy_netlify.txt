PATCH POD NETLIFY — front (Vite) + SPA routing

Co jest w paczce:
- public/_redirects       -> naprawia routing SPA na Netlify
- netlify.toml            -> ustawia build i publish
- tools/patch-scripts.ps1 -> poprawia sekcję "scripts" w package.json (Windows PowerShell)

Jak użyć (60 sekund):
1) Wypakuj paczkę do głównego katalogu projektu (tam gdzie package.json).
   - Zgódź się na nadpisanie netlify.toml
   - Dodaj public/_redirects (jeśli nie ma)

2) Uruchom w PowerShell **w katalogu projektu**:
   powershell -ExecutionPolicy Bypass -File tools/patch-scripts.ps1

   Skrypt ustawi:
     "dev": "vite --host"
     "build": "vite build"
     "preview": "vite preview --host"

3) Zbuduj projekt:
   npm install
   npm run build

4) Na Netlify -> Deploys -> Upload a deploy
   - spakuj folder "dist" do ZIP i wrzuć

5) Test:
   - Otwórz URL Netlify
   - Dodaj do ekranu głównego (PWA)
   - Jeśli używasz pushy, upewnij się że masz serwis worker i staging na https

Opcjonalnie: jeśli masz Netlify Functions (sendPush.js), zostaw w projekcie folder "netlify/functions".
