FA — Cloud Functions (push)

Co robi:
- Wysyła push przy każdej nowej wiadomości w: clients/{clientId}/messages/{msgId}
- HTTPS test: /testPush?clientId=...&title=...&body=...

Wymagania:
1) Zainstaluj Firebase CLI i zaloguj się:
   npm i -g firebase-tools
   firebase login

2) W folderze projektu (gdzie jest firebase.json):
   firebase use --add
   (wybierz projekt: fa-apk-ef676)

3) Zainstaluj zależności funkcji:
   cd functions
   npm install
   cd ..

4) Deploy tylko funkcji:
   firebase deploy --only functions

5) Test:
   - W aplikacji klient włącz powiadomienia (zapis tokenu do clients/{id}.fcmTokens).
   - Dodaj nową wiadomość w clients/{id}/messages -> powinien przyjść push.
   - Albo wejdź w endpoint testowy:
     https://<region>-<project>.cloudfunctions.net/testPush?clientId=client-1&title=Hej&body=Proba

Uwagi:
- Funkcje używają domyślnego service account projektu, nic nie musisz konfigurować.
- Jeśli masz problem z regionem, możesz ograniczyć region w onRequest/onDocumentCreated (domyślnie auto).
- Jeśli chcesz wysyłać push także na „spotkania/szkolenia” — skopiuj handler pod analogiczne ścieżki.
