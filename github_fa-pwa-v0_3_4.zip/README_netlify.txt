NETLIFY FUNCTIONS — PUSH BEZ BLAZE (wersja 2)

Pliki:
- netlify.toml
- package.json (firebase-admin)
- netlify/functions/sendPush.js

Instrukcja:
1) Wypakuj do GŁÓWNEGO katalogu projektu (obok package.json frontu).
2) Na Netlify utwórz site i ustaw ENV:
   - SA_PROJECT_ID = fa-apk-ef676
   - SA_CLIENT_EMAIL = (z service account JSON)
   - SA_PRIVATE_KEY = (z JSON, zamień nowe linie na \n)
3) Deploy (Netlify zrobi bundling funkcji).
4) Test (POST):
   curl -X POST https://<twoja-domena>/.netlify/functions/sendPush      -H "Content-Type: application/json"      -d '{ "clientId": "client-1", "title": "Hej", "body": "To jest test" }'
