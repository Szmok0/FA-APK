/**
 * Firebase Functions — FA push notifications
 * - Fires on creation of a message in clients/{clientId}/messages/{msgId}
 * - Sends FCM notification to all tokens in clients/{clientId}.fcmTokens
 * - Also exposes an HTTPS endpoint to test sending a notification
 */

const { initializeApp } = require('firebase-admin/app');
const { getFirestore } = require('firebase-admin/firestore');
const { getMessaging } = require('firebase-admin/messaging');
const { onDocumentCreated } = require('firebase-functions/v2/firestore');
const { onRequest } = require('firebase-functions/v2/https');
const logger = require('firebase-functions/logger');

initializeApp(); // uses default service account of your project (no extra config)

const db = getFirestore();
const messaging = getMessaging();

/**
 * Helper to send a notification to all tokens stored in clients/{clientId}.fcmTokens
 */
async function sendToClientTokens(clientId, notification, data = {}) {
  const snap = await db.doc(`clients/${clientId}`).get();
  if (!snap.exists) {
    logger.warn(`Client ${clientId} not found`);
    return { sent: 0, errors: ['client-not-found'] };
  }
  const { fcmTokens = [] } = snap.data();
  const tokens = Array.isArray(fcmTokens) ? fcmTokens.filter(Boolean) : [];

  if (!tokens.length) {
    logger.info(`No tokens for client ${clientId}`);
    return { sent: 0, errors: ['no-tokens'] };
  }

  const message = {
    tokens,
    notification,
    data
  };

  const res = await messaging.sendEachForMulticast(message);
  const errors = [];
  res.responses.forEach((r, idx) => {
    if (!r.success) {
      errors.push(`${tokens[idx]}: ${r.error?.code || r.error}`);
    }
  });

  // Optionally prune invalid tokens
  if (errors.length) {
    const invalidTokens = res.responses
      .map((r, i) => ({ r, t: tokens[i] }))
      .filter(({ r }) => !r.success && String(r.error?.code).includes('registration-token'))
      .map(({ t }) => t);

    if (invalidTokens.length) {
      await db.doc(`clients/${clientId}`).update({
        fcmTokens: (db.FieldValue || require('firebase-admin/firestore').FieldValue).arrayRemove(...invalidTokens)
      });
      logger.info(`Pruned ${invalidTokens.length} invalid tokens for ${clientId}`);
    }
  }

  return { sent: res.successCount, failed: res.failureCount, errors };
}

/**
 * Trigger: when a new message is created, notify the client.
 * Expected message fields: author, authorName, text
 */
exports.onMessageCreated = onDocumentCreated('clients/{clientId}/messages/{msgId}', async (event) => {
  const clientId = event.params.clientId;
  const msg = event.data.data();

  const title = msg.author === 'staff'
    ? (msg.authorName || 'Fundacja') + ': nowa wiadomość'
    : 'Nowa wiadomość od klienta';

  const body = (msg.text || '').slice(0, 140);
  const data = { clientId, msgId: event.params.msgId };

  try {
    const res = await sendToClientTokens(clientId, { title, body }, data);
    logger.info(`Push sent for client ${clientId}:`, res);
  } catch (e) {
    logger.error('Error sending push', e);
  }
});

/**
 * HTTPS test endpoint:
 *   GET https://<region>-<project>.cloudfunctions.net/testPush?clientId=client-1&title=Hej&body=Proba
 */
exports.testPush = onRequest(async (req, res) => {
  const clientId = req.query.clientId || 'client-1';
  const title = req.query.title || 'Test powiadomień';
  const body = req.query.body || 'To jest test push';
  try {
    const out = await sendToClientTokens(String(clientId), { title: String(title), body: String(body) }, {});
    res.json({ ok: true, result: out });
  } catch (e) {
    res.status(500).json({ ok: false, error: String(e) });
  }
});
