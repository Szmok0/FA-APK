// netlify/functions/sendPush.js
import { initializeApp, cert } from 'firebase-admin/app';
import { getFirestore, FieldValue } from 'firebase-admin/firestore';
import { getMessaging } from 'firebase-admin/messaging';

let inited = false;
function ensureInit() {
  if (!inited) {
    const projectId = process.env.SA_PROJECT_ID;
    const clientEmail = process.env.SA_CLIENT_EMAIL;
    let privateKey = process.env.SA_PRIVATE_KEY || '';
    privateKey = privateKey.replace(/\\n/g, '\n');
    if (!projectId || !clientEmail || !privateKey) {
      throw new Error('Missing SA envs: SA_PROJECT_ID, SA_CLIENT_EMAIL, SA_PRIVATE_KEY');
    }
    initializeApp({ credential: cert({ projectId, clientEmail, privateKey }) });
    inited = true;
  }
}

export default async (req, res) => {
  if (req.method !== 'POST') {
    res.status(405).json({ ok:false, error:'Method Not Allowed' });
    return;
  }
  try {
    ensureInit();
    const db = getFirestore();
    const messaging = getMessaging();

    const payload = typeof req.body === 'string' ? JSON.parse(req.body||'{}') : (req.body || {});
    const { clientId, title, body, data } = payload;
    if (!clientId || !title) {
      res.status(400).json({ ok:false, error:'clientId and title required' });
      return;
    }

    const snap = await db.doc(`clients/${clientId}`).get();
    if (!snap.exists) {
      res.status(404).json({ ok:false, error:'client not found' });
      return;
    }
    const { fcmTokens = [] } = snap.data();
    const tokens = Array.isArray(fcmTokens) ? fcmTokens.filter(Boolean) : [];
    if (!tokens.length) {
      res.status(200).json({ ok:true, sent:0, note:'no tokens for client' });
      return;
    }

    const out = await messaging.sendEachForMulticast({
      tokens,
      notification: { title, body: body || '' },
      data: data || {}
    });

    const invalid = out.responses
      .map((r,i)=>({ ok:r.success, err:r.error, t:tokens[i] }))
      .filter(x=>!x.ok && String(x.err?.code||'').includes('registration-token'))
      .map(x=>x.t);
    if (invalid.length) {
      await db.doc(`clients/${clientId}`).update({ fcmTokens: FieldValue.arrayRemove(...invalid) });
    }

    res.status(200).json({ ok:true, sent: out.successCount, failed: out.failureCount });
  } catch (e) {
    res.status(500).json({ ok:false, error: String(e) });
  }
};
