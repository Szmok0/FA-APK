/* firebase-messaging-sw.js — musi leżeć w /public i serwować się z "/" */
importScripts('https://www.gstatic.com/firebasejs/10.12.0/firebase-app-compat.js');
importScripts('https://www.gstatic.com/firebasejs/10.12.0/firebase-messaging-compat.js');

// UZUPEŁNIJ swoimi danymi (te same co w src/firebase.ts)
firebase.initializeApp({
  apiKey: "AIzaSyBzP0foHux3MARQqb0LLQdcgOPQyoWwkh8",
  authDomain: "fa-apk-ef676.firebaseapp.com",
  projectId: "fa-apk-ef676",
  storageBucket: "fa-apk-ef676.firebasestorage.app",
  messagingSenderId: "267269499110",
  appId: "1:267269499110:web:f007e277ac63a95451f327",
  measurementId: "G-ES4P605ER1"
});

const messaging = firebase.messaging();

// Tło: wyświetl notyfikację, jeśli payload zawiera "notification"
messaging.onBackgroundMessage((payload) => {
  const title = payload.notification?.title || 'Nowa wiadomość';
  const options = {
    body: payload.notification?.body || '',
    icon: '/icons/icon-192.png',
    badge: '/icons/badge-72.png',
    data: payload.data || {}
  };
  self.registration.showNotification(title, options);
});

self.addEventListener('notificationclick', (event) => {
  event.notification.close();
  event.waitUntil(self.clients.matchAll({ type: 'window', includeUncontrolled: true }).then((clientList) => {
    for (const client of clientList) {
      if ('focus' in client) return client.focus();
    }
    if (self.clients.openWindow) return self.clients.openWindow('/');
  }));
});
