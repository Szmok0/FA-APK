import { Route, Routes } from 'react-router-dom'
import AppBar from './components/AppBar'
import BackToHome from './components/BackToHome'
import Tile from './components/Tile'

// Strony, które masz w projekcie
import Chat from './pages/Chat'
import Meetings from './pages/Meetings'
import Jobs from './pages/Jobs'
import Trainings from './pages/Trainings'
import CV from './pages/CV'
import Contact from './pages/Contact'
import Admin from './pages/Admin'

export default function App(){
  return (
    <div className="min-h-dvh bg-slate-100">
      <AppBar />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/chat" element={<Chat />} />
        <Route path="/meetings" element={<Meetings />} />
        <Route path="/jobs" element={<Jobs />} />
        <Route path="/trainings" element={<Trainings />} />
        <Route path="/cv" element={<CV />} />
        <Route path="/contact" element={<Contact />} />
        <Route path="/admin" element={<Admin />} />
      </Routes>
      <BackToHome />
    </div>
  )
}

function Home() {
  return (
    <div>
      <div className="header-wrap">
        <div className="text-2xl font-bold">Witaj, Jan</div>
        <div className="subtitle">Co chcesz dzisiaj zrobić?</div>
      </div>
      <div className="grid-tiles">
        <Tile linkTo="/chat" title="Czat z Fundacją" color="bg-blue-500" icon={<span className="text-2xl">💬</span>} statusText="Nowe wiadomości" />
        <Tile linkTo="/meetings" title="Twoje Spotkania" color="bg-emerald-600" icon={<span className="text-2xl">📅</span>} statusText="Ustal terminy" />
        <Tile linkTo="/jobs" title="Oferty Pracy" color="bg-amber-500" icon={<span className="text-2xl">👜</span>} />
        <Tile linkTo="/trainings" title="Szkolenia" color="bg-violet-600" icon={<span className="text-2xl">🧠</span>} />
        <Tile linkTo="/cv" title="Twoje CV" color="bg-slate-500" icon={<span className="text-2xl">📄</span>} />
        <Tile linkTo="/contact" title="Kontakt" color="bg-teal-600" icon={<span className="text-2xl">☎</span>} />
        <Tile linkTo="/admin" title="Panel Admin" color="bg-slate-800" icon={<span className="text-2xl">🛠</span>} />
      </div>
    </div>
  )
}
