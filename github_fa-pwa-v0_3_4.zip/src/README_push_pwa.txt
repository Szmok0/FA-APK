PUSH + PWA PACK — KROTKI SETUP

1) Skopiuj pliki:
   - public/firebase-messaging-sw.js  (UWAGA: plik musi być serwowany z / )
   - src/push.ts
   - public/manifest.webmanifest  (podmień jeśli już masz)

   Jeśli nie masz folderu public/icons/, dodaj własne PNG 192 i 512 px (albo tymczasowe).

2) Sprawdź w kodzie:
   - W push.ts jest VAPID_KEY. Zostawiłem Twój aktualny VAPID do testów.
   - W SW są Twoje firebaseConfig.

3) Dev test (localhost):
   - npm run dev -- --host
   - /admin → Włącz powiadomienia (musi być zgoda przeglądarki)
   - W tle notyfikacje pokażą się TYLKO jeśli payload ma "notification.title/body".

4) Staging HTTPS (żeby push działał pewnie):
   - Wystaw projekt na Netlify/Vercel (darmowe HTTPS). Push w LAN bywa blokowany.
   - Po wdrożeniu odwiedź stronę na telefonie → Dodaj do ekranu głównego (PWA).

5) Wysyłka powiadomień:
   - Produkcyjnie potrzebny jest serwer (np. Cloud Function), który wyśle do FCM HTTP v1.
   - Najprostszy wariant: funkcja "onCreate" na sub-kolekcji (np. messages) -> wysyła notyfikację na fcmTokens klienta.
   - Jeśli chcesz, przygotuję folder 'functions/' z gotową funkcją i krótką instrukcją 'firebase deploy --only functions'.
