import { Link, useLocation } from 'react-router-dom'
export default function AppBar(){
  const loc = useLocation(); const home = loc.pathname === '/'
  const titleMap:Record<string,string>={ '/chat':'Czat z Fundacją','/meetings':'Twoje Spotkania','/jobs':'Oferty Pracy','/trainings':'Szkolenia i Warsztaty','/cv':'Twoje CV','/contact':'Kontakt do Fundacji','/admin':'Panel Admin' }
  const key='/' + loc.pathname.split('/')[1]; const title= home?'':(titleMap[key]??'')
  return (<div className='appbar'><div className='flex items-center gap-3'>{!home && <Link to='/' aria-label='Wróć' className='text-white text-xl'>←</Link>}<div className='title'>{title}</div></div></div>) }
