import { Link, useLocation } from "react-router-dom";

export default function BackToHome() {
  const loc = useLocation();
  const onHome = loc.pathname === "/";
  if (onHome) return null;

  return (
    <Link
      to="/"
      className="fixed left-3 bottom-3 z-50 rounded-full bg-black/80 text-white text-base px-4 py-3 shadow-lg"
      aria-label="Wróć do ekranu głównego"
    >
      ← Wróć
    </Link>
  );
}
