import { Link } from 'react-router-dom'
import type { ReactNode } from 'react'

type Props={linkTo:string;title:string;icon?:ReactNode;statusText?:string;color?:string}
export default function Tile({linkTo,title,icon,statusText,color='bg-blue-500'}:Props){
  return (
    <Link to={linkTo} className={`rounded-xl p-4 text-white shadow-card relative min-h-[120px] block ${color}`}>
      <div className='text-3xl'>{icon ?? '⬛'}</div>
      <div className='text-lg font-semibold mt-1'>{title}</div>
      {statusText && <div className='badge absolute bottom-2 right-2'>{statusText}</div>}
    </Link>
  )
}
