import { db } from '../firebase'
import { collection, addDoc, serverTimestamp, onSnapshot, query, orderBy } from 'firebase/firestore'

export function listenMessages(clientId:string, cb:(msgs:any[])=>void){
  const q=query(collection(db,'clients',clientId,'messages'), orderBy('createdAt','asc'))
  return onSnapshot(q, snap=>{ cb(snap.docs.map(d=>({ id:d.id, ...d.data() }))) })
}
export async function sendMessage(clientId:string, text:string){
  await addDoc(collection(db,'clients',clientId,'messages'),{ author:'client', authorName:'Ty', text, createdAt: serverTimestamp() })
}
