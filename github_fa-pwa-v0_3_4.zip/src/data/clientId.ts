// src/data/clientId.ts
export function getClientId(): string | null {
  // jeśli nie ma jeszcze przypięcia, zwróć null – ekrany użyją fallbacku 'client-1'
  return localStorage.getItem('fa_client_id');
}

export function setClientId(id: string) {
  localStorage.setItem('fa_client_id', id);
}

export function clearClientId() {
  localStorage.removeItem('fa_client_id');
}
