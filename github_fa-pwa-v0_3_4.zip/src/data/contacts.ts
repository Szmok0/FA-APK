import { db } from '../firebase'
import { collection, onSnapshot, query, orderBy, doc, updateDoc, deleteDoc } from 'firebase/firestore'

export function listenContacts(clientId:string, cb:(items:any[])=>void){
  const q = query(collection(db, 'clients', clientId, 'contacts'), orderBy('createdAt','desc'))
  return onSnapshot(q, snap=>cb(snap.docs.map(d=>({ id:d.id, ...d.data() }))))
}

export async function updateContact(clientId:string, id:string, data:{ name?:string; role?:string; phone?:string }){
  await updateDoc(doc(db, 'clients', clientId, 'contacts', id), data)
}

export async function deleteContact(clientId:string, id:string){
  await deleteDoc(doc(db, 'clients', clientId, 'contacts', id))
}
