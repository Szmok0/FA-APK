// src/data/jobs.ts
import { db } from '../firebase'
import { collection, onSnapshot, query, orderBy, doc, updateDoc } from 'firebase/firestore'

export function listenJobs(clientId:string, cb:(items:any[])=>void){
  const q = query(collection(db, 'clients', clientId, 'jobs'), orderBy('createdAt','desc'))
  return onSnapshot(q, snap=>cb(snap.docs.map(d=>({ id:d.id, ...d.data() }))))
}
export async function setJobStatus(clientId:string, id:string, status:'applied'|'rejected'|'new'){
  await updateDoc(doc(db, 'clients', clientId, 'jobs', id), { status })
}