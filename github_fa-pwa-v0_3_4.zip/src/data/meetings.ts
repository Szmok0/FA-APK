import { db } from '../firebase'
import { collection, doc, updateDoc, onSnapshot, query, orderBy } from 'firebase/firestore'
export function listenMeetings(clientId:string, cb:(items:any[])=>void){
  const q=query(collection(db,'clients',clientId,'meetings'), orderBy('startsAt','asc'))
  return onSnapshot(q, snap=>{ cb(snap.docs.map(d=>({ id:d.id, ...d.data() }))) })
}
export async function confirmMeeting(clientId:string, id:string){ await updateDoc(doc(db,'clients',clientId,'meetings',id), { status:'confirmed' }) }
export async function declineMeeting(clientId:string, id:string){ await updateDoc(doc(db,'clients',clientId,'meetings',id), { status:'declined' }) }
