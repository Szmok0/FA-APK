// src/data/trainings.ts
import { db } from '../firebase'
import { collection, onSnapshot, query, orderBy, doc, updateDoc } from 'firebase/firestore'

export function listenTrainings(clientId:string, cb:(items:any[])=>void){
  const q = query(collection(db, 'clients', clientId, 'trainings'), orderBy('startsAt','asc'))
  return onSnapshot(q, snap=>cb(snap.docs.map(d=>({ id:d.id, ...d.data() }))))
}
export async function setTrainingStatus(clientId:string, id:string, status:'confirmed'|'declined'|'planned'){
  await updateDoc(doc(db, 'clients', clientId, 'trainings', id), { status })
}