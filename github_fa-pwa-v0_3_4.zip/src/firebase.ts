import { initializeApp } from 'firebase/app'
import { getFirestore } from 'firebase/firestore'
import firebaseCompat from 'firebase/compat/app'
import 'firebase/compat/messaging'

export const firebaseConfig = {
  "apiKey": "AIzaSyBzP0foHux3MARQqb0LLQdcgOPQyoWwkh8",
  "authDomain": "fa-apk-ef676.firebaseapp.com",
  "projectId": "fa-apk-ef676",
  "storageBucket": "fa-apk-ef676.firebasestorage.app",
  "messagingSenderId": "267269499110",
  "appId": "1:267269499110:web:f007e277ac63a95451f327",
  "measurementId": "G-ES4P605ER1"
}

export const app = initializeApp(firebaseConfig)
export const db = getFirestore(app)
try{ if(!firebaseCompat.apps.length){ firebaseCompat.initializeApp(firebaseConfig) } }catch{}
export { firebaseCompat }
