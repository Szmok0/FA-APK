import { useEffect, useState } from 'react'
import { db } from '../firebase'
import { collection, addDoc, doc, setDoc, serverTimestamp } from 'firebase/firestore'
import { enablePushForClient } from '../push'
import { listenContacts, updateContact, deleteContact } from '../data/contacts'

const CLIENT_ID = 'client-1' // jeśli masz helper getClientId() — możesz go tu użyć
const STAFF_PIN = '1357'     // tymczasowy PIN do panelu pracownika

export default function Admin(){
  const [isStaff, setIsStaff] = useState(false)
  useEffect(()=>{ setIsStaff(localStorage.getItem('fa_staff')==='1') },[])

  if(!isStaff){
    return (
      <div className="max-w-md mx-auto p-4 space-y-3">
        <div className="card">
          <div className="font-semibold">Tylko dla pracowników</div>
          <p className="text-sm text-slate-600 mt-1">Podaj PIN, aby wejść.</p>
          <PinGate onOk={()=>{ localStorage.setItem('fa_staff','1'); location.reload() }} />
        </div>
      </div>
    )
  }

  return <AdminBody />
}

function PinGate({ onOk }:{ onOk:()=>void }){
  const [pin, setPin] = useState('')
  return (
    <div className="mt-2 flex gap-2">
      <input value={pin} onChange={e=>setPin(e.target.value)} className="flex-1 rounded-lg p-2 border" placeholder="PIN" />
      <button onClick={()=>{ if(pin===STAFF_PIN) onOk(); else alert('Zły PIN') }} className="btn btn-primary">Wejdź</button>
    </div>
  )
}

function AdminBody(){
  // CHAT
  const [msg, setMsg] = useState('')

  // SPOTKANIA
  const [title, setTitle] = useState('')
  const [date, setDate] = useState('')

  // OFERTY
  const [jobTitle, setJobTitle] = useState('')
  const [jobUrl, setJobUrl] = useState('')

  // SZKOLENIA
  const [trTitle, setTrTitle] = useState('')
  const [trDate, setTrDate] = useState('')

  // KONTAKTY – dodawanie
  const [cName, setCName] = useState('')
  const [cRole, setCRole] = useState('')
  const [cPhone, setCPhone] = useState('')

  // KONTAKTY – lista + edycja
  const [contacts, setContacts] = useState<any[]>([])
  const [editId, setEditId] = useState<string | null>(null)
  const [editName, setEditName] = useState('')
  const [editRole, setEditRole] = useState('')
  const [editPhone, setEditPhone] = useState('')

  useEffect(()=>{
    const un = listenContacts(CLIENT_ID, setContacts)
    return ()=>un()
  }, [])

  async function sendStaffMessage(){
    if(!msg.trim()) return
    await addDoc(collection(db, 'clients', CLIENT_ID, 'messages'), {
      author: 'staff', authorName: 'Pracownik', text: msg.trim(), createdAt: serverTimestamp()
    })
    setMsg('')
  }

  async function addMeeting(){
    if(!title.trim() || !date) return
    await addDoc(collection(db, 'clients', CLIENT_ID, 'meetings'), {
      title: title.trim(), startsAt: new Date(date), status: 'planned'
    })
    setTitle(''); setDate('')
  }

  async function addJob(){
    if(!jobTitle.trim() || !jobUrl.trim()) return
    await addDoc(collection(db, 'clients', CLIENT_ID, 'jobs'), {
      title: jobTitle.trim(), url: jobUrl.trim(), status: 'new', createdAt: serverTimestamp()
    })
    setJobTitle(''); setJobUrl('')
  }

  async function addTraining(){
    if(!trTitle.trim() || !trDate) return
    await addDoc(collection(db, 'clients', CLIENT_ID, 'trainings'), {
      title: trTitle.trim(), startsAt: new Date(trDate), status: 'planned', createdAt: serverTimestamp()
    })
    setTrTitle(''); setTrDate('')
  }

  // Prosta normalizacja numeru – PL
  const formatPhone = (phone: string) => {
    const digits = phone.replace(/\D/g, '');
    if (!digits) return '';
    if (digits.startsWith('48')) return '+' + digits;   // np. 48501111222 -> +48501111222
    if (digits.length === 9) return '+48' + digits;     // np. 501111222 -> +48501111222
    return (phone.startsWith('+') ? '' : '+') + digits; // fallback
  };

  async function addContact(){
    if(!cName.trim() || !cRole.trim() || !cPhone.trim()) return
    const phone = formatPhone(cPhone.trim())
    await addDoc(collection(db, 'clients', CLIENT_ID, 'contacts'), {
      name: cName.trim(), role: cRole.trim(), phone, createdAt: serverTimestamp()
    })
    setCName(''); setCRole(''); setCPhone('')
  }

  function startEdit(c:any){
    setEditId(c.id); setEditName(c.name||''); setEditRole(c.role||''); setEditPhone(c.phone||'')
  }
  async function saveEdit(){
    if(!editId) return
    const phone = formatPhone(editPhone.trim())
    await updateContact(CLIENT_ID, editId, { name: editName.trim(), role: editRole.trim(), phone })
    setEditId(null)
  }
  async function removeContact(id:string){
    if(!confirm('Usunąć kontakt?')) return
    await deleteContact(CLIENT_ID, id)
  }

  async function seedDemo(){
    await setDoc(doc(db, 'clients', CLIENT_ID), { displayName:'Jan', fcmTokens: [] }, { merge: true })
    await addDoc(collection(db, 'clients', CLIENT_ID, 'messages'), {
      author:'staff', authorName:'Jacek (Doradca)', text:'Dzień dobry! To wiadomość testowa.', createdAt: serverTimestamp()
    })
    await addDoc(collection(db, 'clients', CLIENT_ID, 'meetings'), {
      title:'Spotkanie w fundacji', startsAt:new Date(Date.now()+36e5*24), location:'Biuro FA, pokój 3', status:'planned'
    })
    await addDoc(collection(db, 'clients', CLIENT_ID, 'contacts'), {
      name:'Agnieszka Kowalska', role:'Psycholog', phone:'+48500100100', createdAt: serverTimestamp()
    })
    alert('Zasiane: client-1 + przykładowe dane (wiadomość/spotkanie/kontakt)')
  }

  async function turnOnPush(){
    const res = await enablePushForClient(CLIENT_ID)
    alert('Push: ' + JSON.stringify(res))
  }

  return (
    <div className="max-w-md mx-auto p-4 space-y-4">
      <div className="card"><div className="font-semibold">Seed danych demo</div>
        <button onClick={seedDemo} className="btn btn-success mt-2">Zasiej dane</button>
      </div>

      <div className="card"><div className="font-semibold">Push (FCM)</div>
        <button onClick={turnOnPush} className="btn btn-primary mt-2">Włącz powiadomienia na tym urządzeniu</button>
      </div>

      <div className="card"><div className="font-semibold">Wyślij wiadomość (jako pracownik)</div>
        <div className="mt-2 flex gap-2">
          <input value={msg} onChange={e=>setMsg(e.target.value)} className="flex-1 rounded-lg p-2 border" placeholder="Treść…" />
          <button onClick={sendStaffMessage} className="btn btn-primary">Wyślij</button>
        </div>
      </div>

      <div className="card"><div className="font-semibold">Dodaj spotkanie</div>
        <input value={title} onChange={e=>setTitle(e.target.value)} className="w-full rounded-lg p-2 border mt-2" placeholder="Tytuł" />
        <input value={date} onChange={e=>setDate(e.target.value)} type="datetime-local" className="w-full rounded-lg p-2 border mt-2" />
        <button onClick={addMeeting} className="btn btn-success mt-2">Dodaj</button>
      </div>

      <div className="card"><div className="font-semibold">Dodaj ofertę pracy</div>
        <input value={jobTitle} onChange={e=>setJobTitle(e.target.value)} className="w-full rounded-lg p-2 border mt-2" placeholder="Tytuł oferty" />
        <input value={jobUrl} onChange={e=>setJobUrl(e.target.value)} className="w-full rounded-lg p-2 border mt-2" placeholder="URL ogłoszenia" />
        <button onClick={addJob} className="btn btn-success mt-2">Dodaj</button>
      </div>

      <div className="card"><div className="font-semibold">Dodaj szkolenie / warsztat</div>
        <input value={trTitle} onChange={e=>setTrTitle(e.target.value)} className="w-full rounded-lg p-2 border mt-2" placeholder="Tytuł" />
        <input value={trDate} onChange={e=>setTrDate(e.target.value)} type="datetime-local" className="w-full rounded-lg p-2 border mt-2" />
        <button onClick={addTraining} className="btn btn-success mt-2">Dodaj</button>
      </div>

      <div className="card"><div className="font-semibold">Dodaj kontakt do pracownika</div>
        <input value={cName} onChange={e=>setCName(e.target.value)} className="w-full rounded-lg p-2 border mt-2" placeholder="Imię i nazwisko" />
        <input value={cRole} onChange={e=>setCRole(e.target.value)} className="w-full rounded-lg p-2 border mt-2" placeholder="Rola / funkcja" />
        <input value={cPhone} onChange={e=>setCPhone(e.target.value)} className="w-full rounded-lg p-2 border mt-2" placeholder="Telefon (+48… lub 9 cyfr)" />
        <button onClick={addContact} className="btn btn-success mt-2">Dodaj</button>
      </div>

      {/* Zarządzanie kontaktami */}
      <div className="card">
        <div className="font-semibold mb-2">Kontakty klienta</div>
        {!contacts.length && <div className="text-sm text-slate-600">Brak kontaktów.</div>}
        <div className="space-y-2">
          {contacts.map(c => (
            <div key={c.id} className="border rounded-lg p-2">
              {editId === c.id ? (
                <div className="space-y-2">
                  <input value={editName} onChange={e=>setEditName(e.target.value)} className="w-full rounded-lg p-2 border" placeholder="Imię i nazwisko" />
                  <input value={editRole} onChange={e=>setEditRole(e.target.value)} className="w-full rounded-lg p-2 border" placeholder="Rola" />
                  <input value={editPhone} onChange={e=>setEditPhone(e.target.value)} className="w-full rounded-lg p-2 border" placeholder="Telefon" />
                  <div className="flex gap-2">
                    <button onClick={saveEdit} className="btn btn-primary">Zapisz</button>
                    <button onClick={()=>setEditId(null)} className="btn btn-muted">Anuluj</button>
                  </div>
                </div>
              ) : (
                <div className="flex items-center justify-between gap-3">
                  <div className="min-w-0">
                    <div className="font-semibold truncate">{c.name}</div>
                    <div className="text-sm text-slate-600 truncate">{c.role}</div>
                    <div className="text-sm text-slate-700">{c.phone}</div>
                  </div>
                  <div className="shrink-0 flex gap-2">
                    <button onClick={()=>startEdit(c)} className="btn btn-primary">Edytuj</button>
                    <button onClick={()=>removeContact(c.id)} className="btn btn-muted">Usuń</button>
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>

      <div className="text-xs text-slate-500">Panel pracownika – klient: {CLIENT_ID}. PIN (tymczasowy): {STAFF_PIN}.</div>
    </div>
  )
}
