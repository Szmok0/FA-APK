import { useEffect, useRef, useState } from 'react'
import { listenMessages, sendMessage } from '../data/chat'
const CLIENT_ID='client-1'
export default function Chat(){
  const [messages,setMessages]=useState<any[]>([]); const [text,setText]=useState(''); const listRef=useRef<HTMLDivElement>(null)
  useEffect(()=>{ const u=listenMessages(CLIENT_ID,setMessages); return ()=>u() },[])
  useEffect(()=>{ listRef.current?.scrollTo({ top: 9e9, behavior:'smooth' }) },[messages])
  async function onSend(){ const t=text.trim(); if(!t) return; setText(''); await sendMessage(CLIENT_ID,t) }
  return (<div className='max-w-md mx-auto p-4'>
    <div ref={listRef} className='bg-white rounded-xl p-3 shadow-card h-[65vh] overflow-y-auto space-y-2'>
      {messages.map((m:any)=>(<div key={m.id} className={`max-w-[85%] ${m.author==='client'?'ml-auto text-white':'mr-auto text-slate-900'}`}>
        <div className={`px-3 py-2 rounded-2xl ${m.author==='client'?'bg-blue-600':'bg-slate-200'}`}>{m.text}</div>
        <div className='text-[10px] opacity-60 mt-1'>{m.author==='client'?'Ty':m.authorName}</div>
      </div>))}
      {!messages.length && <div className='text-sm text-slate-500'>Brak wiadomości. Napisz pierwszą lub dodaj w Admin.</div>}
    </div>
    <div className='mt-3 flex gap-2'>
      <input value={text} onChange={e=>setText(e.target.value)} placeholder='Napisz wiadomość…' className='flex-1 rounded-xl p-3 outline-none bg-white shadow-inner'/>
      <button onClick={onSend} className='btn btn-primary'>Wyślij</button>
    </div>
  </div>)
}
