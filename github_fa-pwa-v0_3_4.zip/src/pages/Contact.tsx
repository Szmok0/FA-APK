import { useEffect, useState } from 'react'
import { listenContacts } from '../data/contacts'
import { getClientId } from '../data/clientId' // jeśli nie masz helpera, zastąp stałą 'client-1'

const CLIENT_ID = (typeof getClientId === 'function' && getClientId()) || 'client-1'

export default function Contact(){
  const [items, setItems] = useState<any[]>([])
  useEffect(()=>{ const u = listenContacts(CLIENT_ID, setItems); return ()=>u() },[])

  return (
    <div className="max-w-md mx-auto p-4 space-y-3">
      {/* Info box */}
      <div className="bg-blue-50 rounded-xl p-3 shadow-card border-l-4 border-blue-500">
        <div className="font-semibold text-slate-800">Naciśnij na kafelek, aby zadzwonić.</div>
        <div className="text-sm text-slate-600">Połączenie zostanie wykonane za pomocą Twojego telefonu.</div>
      </div>

      {/* Lista kontaktów */}
      {items.map(p => (
        <a key={p.id} href={p.phone ? `tel:${p.phone}` : undefined} className="card block">
          <div className="flex items-center justify-between gap-3">
            <div className="min-w-0">
              <div className="font-semibold truncate">{p.name}</div>
              <div className="text-sm text-slate-600 truncate">{p.role}</div>
            </div>
            <div className="shrink-0">
              <div className={`w-12 h-12 grid place-items-center rounded-full shadow ${p.phone ? 'bg-emerald-500 text-white' : 'bg-slate-300 text-slate-500'}`} aria-label="Zadzwoń">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="22" height="22" fill="currentColor">
                  <path d="M6.62 10.79a15.053 15.053 0 006.59 6.59l2.2-2.2a1 1 0 011.02-.24c1.12.37 2.33.57 3.57.57a1 1 0 011 1V21a1 1 0 01-1 1C10.07 22 2 13.93 2 3a1 1 0 011-1h3.5a1 1 0 011 1c0 1.24.2 2.45.57 3.57a1 1 0 01-.24 1.02l-2.2 2.2z"/>
                </svg>
              </div>
            </div>
          </div>
        </a>
      ))}

      {!items.length && <div className="text-sm text-slate-600">Brak kontaktów. Dodaj w panelu Admin → „Dodaj kontakt do pracownika”.</div>}
    </div>
  )
}
