import { useEffect, useState } from 'react'
import { listenJobs, setJobStatus } from '../data/jobs'
import { getClientId } from '../data/clientId' // jeśli brak helpera, użyj stałej 'client-1'

const CLIENT_ID = (typeof getClientId === 'function' && getClientId()) || 'client-1'

function Badge({ text, tone='green' }:{ text:string, tone?:'green'|'slate'|'red'}){
  const map:any = {
    green: 'bg-emerald-100 text-emerald-800',
    slate: 'bg-slate-200 text-slate-700',
    red:   'bg-red-100 text-red-800'
  }
  return <span className={`text-xs px-2 py-1 rounded-full ${map[tone]}`}>{text}</span>
}

export default function Jobs(){
  const [items, setItems] = useState<any[]>([])
  useEffect(()=>{ const u = listenJobs(CLIENT_ID, setItems); return ()=>u() },[])

  if(!items.length) return <div className="max-w-md mx-auto p-4 text-slate-600">Brak ofert. Dodaj w panelu Admin.</div>

  return (
    <div className="max-w-md mx-auto p-4 space-y-3">
      {items.map(j => (
        <div key={j.id} className="card relative overflow-hidden">
          {/* lewy akcent jak na screenie */}
          <div className="absolute left-0 top-0 bottom-0 w-[6px] bg-amber-400 rounded-l-xl" />

          <div className="flex items-start justify-between gap-3 pr-2">
            <div className="min-w-0">
              <div className="font-semibold">{j.title}</div>
              {j.company && <div className="text-sm text-slate-700">{j.company}</div>}
            </div>
            {/* status w prawym górnym rogu */}
            {j.status === 'applied' && <Badge text="Aplikowano" tone="green" />}
            {j.status === 'rejected' && <Badge text="Odrzucona" tone="red" />}
            {(!j.status || j.status === 'new') && <Badge text="Wyświetlona" tone="slate" />}
          </div>

          {j.description && <div className="text-sm text-slate-700 mt-2">{j.description}</div>}

          {/* przycisk 'Zobacz ofertę' */}
          {j.url && (
            <a href={j.url} target="_blank" rel="noreferrer" className="block mt-3 border rounded-lg px-4 py-2 text-center text-slate-800 hover:bg-slate-50">
              Zobacz Ofertę
            </a>
          )}

          {/* przyciski akcji */}
          <div className="mt-3 flex gap-2">
            {j.status !== 'applied' && (
              <button onClick={()=>setJobStatus(CLIENT_ID, j.id, 'applied')} className="btn btn-success">
                Aplikuję
              </button>
            )}
            {j.status !== 'applied' && (
              <button onClick={()=>setJobStatus(CLIENT_ID, j.id, 'rejected')} className="btn btn-muted">
                Odrzucam
              </button>
            )}
          </div>
        </div>
      ))}
    </div>
  )
}
