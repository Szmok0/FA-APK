import { useEffect, useState } from 'react'
import { listenMeetings, confirmMeeting, declineMeeting } from '../data/meetings'
const CLIENT_ID='client-1'
function fmt(ts:any){ try{ return new Date(ts?.seconds?ts.seconds*1000:ts).toLocaleString('pl-PL',{weekday:'long',year:'numeric',month:'long',day:'numeric',hour:'2-digit',minute:'2-digit'}) }catch{ return '' } }
export default function Meetings(){ const [items,setItems]=useState<any[]>([])
  useEffect(()=>{ const u=listenMeetings(CLIENT_ID,setItems); return ()=>u() },[])
  return (<div className='max-w-md mx-auto p-4 space-y-3'>
    {items.map((m:any)=>(<div key={m.id} className='card card-accent'>
      <div className='font-semibold'>{m.title}</div>
      <div className='text-sm text-slate-600'>{fmt(m.startsAt)}</div>
      {m.location && <div className='text-sm text-slate-500'>Lokalizacja: {m.location}</div>}
      <div className='mt-2 flex gap-2'>
        {m.status!=='confirmed' && <button onClick={()=>confirmMeeting(CLIENT_ID,m.id)} className='btn btn-primary'>Potwierdzam</button>}
        {m.status!=='confirmed' && <button onClick={()=>declineMeeting(CLIENT_ID,m.id)} className='btn btn-muted'>Odrzuć</button>}
      </div>
      {m.status==='confirmed' && <div className='mt-2 bg-emerald-100 text-emerald-800 text-sm px-3 py-2 rounded-lg w-fit'>Potwierdzone</div>}
      {m.status==='declined' && <div className='mt-2 bg-red-100 text-red-800 text-sm px-3 py-2 rounded-lg w-fit'>Odrzucone</div>}
    </div>))}
    {!items.length && <div className='text-sm text-slate-500'>Brak spotkań. Dodaj w panelu Admin.</div>}
  </div>) }
