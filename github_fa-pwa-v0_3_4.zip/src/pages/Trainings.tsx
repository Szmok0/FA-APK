import { useEffect, useState } from 'react'
import { listenTrainings, setTrainingStatus } from '../data/trainings'
const CLIENT_ID = 'client-1'

function fmt(ts:any){
  try { return new Date(ts?.seconds? ts.seconds*1000:ts).toLocaleString('pl-PL', {weekday:'long', year:'numeric', month:'long', day:'numeric', hour:'2-digit', minute:'2-digit'}) } catch { return '' }
}

export default function Trainings(){
  const [items, setItems] = useState<any[]>([])
  useEffect(()=>{ const u = listenTrainings(CLIENT_ID, setItems); return ()=>u() },[])
  if(!items.length) return <div className="max-w-md mx-auto p-4 text-slate-600">Brak szkoleń. Dodaj w panelu Admin.</div>

  return (
    <div className="max-w-md mx-auto p-4 space-y-3">
      {items.map(t=>(
        <div key={t.id} className="card card-accent">
          <div className="font-semibold">{t.title}</div>
          <div className="text-sm text-slate-600">{fmt(t.startsAt)}</div>
          <div className="mt-2 flex gap-2">
            {t.status!=='confirmed' && <button onClick={()=>setTrainingStatus(CLIENT_ID, t.id, 'confirmed')} className="btn btn-primary">Potwierdzam</button>}
            {t.status!=='confirmed' && <button onClick={()=>setTrainingStatus(CLIENT_ID, t.id, 'declined')} className="btn btn-muted">Nie pasuje</button>}
          </div>
          {t.status==='confirmed' && <div className="mt-2 bg-emerald-100 text-emerald-800 text-sm px-3 py-2 rounded-lg w-fit">Potwierdzone</div>}
          {t.status==='declined' && <div className="mt-2 bg-red-100 text-red-800 text-sm px-3 py-2 rounded-lg w-fit">Nie pasuje</div>}
        </div>
      ))}
    </div>
  )
}
