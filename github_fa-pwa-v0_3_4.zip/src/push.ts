// src/push.ts — centralne włączanie powiadomień i zapis tokenu
import { isSupported, getMessaging, getToken, onMessage } from 'firebase/messaging'
import { app, db } from './firebase'
import { doc, setDoc, arrayUnion, updateDoc } from 'firebase/firestore'

const VAPID_KEY = import.meta.env.VITE_VAPID_KEY || 'BKeAWLhBaUg-auAq7hAtQ60z-SXUFMq-hpUxg7_vMEoDmLdm66ZeM0JpAi530yEY8xjcChHT1JHahqU1y3hFPbs'

export async function enablePushForClient(clientId: string){
  try{
    const ok = await isSupported();
    if(!ok) return { ok:false, reason:'not-supported' }

    const perm = await Notification.requestPermission();
    if(perm !== 'granted') return { ok:false, reason:'denied' }

    const messaging = getMessaging(app);
    const token = await getToken(messaging, { vapidKey: VAPID_KEY, serviceWorkerRegistration: await navigator.serviceWorker.ready });

    if(!token) return { ok:false, reason:'no-token' }

    // zapisz token do klienta
    const ref = doc(db, 'clients', clientId);
    await setDoc(ref, { fcmTokens: arrayUnion(token) }, { merge:true });
    await updateDoc(ref, { lastTokenAt: new Date() } as any);

    // foreground notifications
    onMessage(messaging, (payload)=>{
      // prosty toast/alert – możesz podmienić na ładniejszy UI
      if(payload?.notification?.title){
        console.log('[FCM] onMessage', payload);
      }
    });

    return { ok:true, token };
  }catch(e:any){
    console.error('enablePushForClient error', e);
    return { ok:false, error: String(e) }
  }
}
