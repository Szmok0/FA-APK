# tools/patch-scripts.ps1
Param([string]$FilePath = "package.json")

if (!(Test-Path $FilePath)) {
  Write-Error "Nie znaleziono $FilePath (uruchom skrypt w katalogu projektu)"
  exit 1
}

# Wczytaj JSON
$raw = Get-Content $FilePath -Raw -Encoding UTF8
$json = $raw | ConvertFrom-Json

if (-not $json.scripts) {
  $json | Add-Member -MemberType NoteProperty -Name scripts -Value @{}
}

$json.scripts.dev = "vite --host"
$json.scripts.build = "vite build"
$json.scripts.preview = "vite preview --host"

# Zapisz z powrotem
$json | ConvertTo-Json -Depth 20 | Out-File $FilePath -Encoding UTF8

Write-Host "Zaktualizowano sekcję 'scripts' w package.json." -ForegroundColor Green
